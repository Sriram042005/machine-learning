import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, roc_auc_score, roc_curve, classification_report, confusion_matrix
)

st.set_page_config(page_title="Breast Cancer Detection", layout="wide")

@st.cache_data
def load_data():
    data_bunch = load_breast_cancer(as_frame=True)
    X = data_bunch.data
    y = data_bunch.target
    feature_names = list(X.columns)
    target_names = list(data_bunch.target_names)
    return X, y, feature_names, target_names

@st.cache_resource
def train_model(X, y, random_state=42):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_state, stratify=y
    )
    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(max_iter=1000))
    ])
    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)
    y_proba = pipe.predict_proba(X_test)[:, 1]
    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba),
        "report": classification_report(y_test, y_pred, target_names=["malignant", "benign"]),
        "cm": confusion_matrix(y_test, y_pred),
        "X_test": X_test,
        "y_test": y_test,
        "y_proba": y_proba
    }
    return pipe, metrics

def main():
    st.title("Breast Cancer Detection (Scikit-learn + Streamlit)")

    st.markdown(
        "This demo trains a Logistic Regression classifier on the built-in Breast Cancer Wisconsin dataset and "
        "lets you make predictions from dataset samples or manual inputs. For learning/demo purposes only."
    )

    # Load data and train
    X, y, feature_names, target_names = load_data()
    model, metrics = train_model(X, y)

    # Sidebar controls
    st.sidebar.header("Prediction Mode")
    mode = st.sidebar.radio(
        "Choose input method:",
        ["Use dataset sample", "Manual input"]
    )

    st.sidebar.header("Model Options")
    rs = st.sidebar.number_input("Random state (retrain if changed)", value=42, step=1)
    if st.sidebar.button("Retrain Model"):
        st.cache_resource.clear()
        model, metrics = train_model(X, y, random_state=int(rs))
        st.sidebar.success("Model retrained.")

    # Tabs for UI
    tab_pred, tab_metrics, tab_data = st.tabs(["Predict", "Metrics", "Dataset"])

    with tab_pred:
        st.subheader("Make a Prediction")
        if mode == "Use dataset sample":
            idx = st.number_input("Pick sample index from test-like range", min_value=0, max_value=len(X)-1, value=0, step=1)
            sample = X.iloc[[idx]]
            st.write("Feature values:", sample)
        else:
            st.write("Enter feature values (defaults set to dataset means).")
            defaults = X.mean()
            inputs = {}
            cols = st.columns(3)
            for i, feat in enumerate(feature_names):
                with cols[i % 3]:
                    inputs[feat] = st.number_input(
                        feat, value=float(np.round(defaults[feat], 3))
                    )
            sample = pd.DataFrame([inputs], columns=feature_names)

        if st.button("Predict"):
            pred_class = model.predict(sample)
            pred_proba = model.predict_proba(sample)[0, 1]
            label = "benign" if pred_class == 1 else "malignant"
            st.success(f"Prediction: {label.upper()}  |  Probability (benign class=1): {pred_proba:.3f}")

    with tab_metrics:
        st.subheader("Evaluation on Hold-out Set")
        st.write(f"Accuracy: {metrics['accuracy']:.4f}")
        st.write(f"ROC AUC: {metrics['roc_auc']:.4f}")
        st.text("Classification Report:")
        st.text(metrics["report"])

        # Confusion matrix
        cm = metrics["cm"]
        fig, ax = plt.subplots(figsize=(4, 4))
        im = ax.imshow(cm, cmap="Blues")
        ax.set_title("Confusion Matrix")
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        ax.set_xticks([0, 1])
        ax.set_yticks([0, 1])
        ax.set_xticklabels(["malignant", "benign"])
        ax.set_yticklabels(["malignant", "benign"])
        for (i, j), z in np.ndenumerate(cm):
            ax.text(j, i, str(z), ha='center', va='center')
        fig.colorbar(im, ax=ax)
        st.pyplot(fig)

        # ROC Curve
        fpr, tpr, _ = roc_curve(metrics["y_test"], metrics["y_proba"])
        fig2, ax2 = plt.subplots(figsize=(5, 4))
        ax2.plot(fpr, tpr, label=f"AUC = {metrics['roc_auc']:.3f}")
        ax2.plot([0, 1], [0, 1], 'k--', label="Chance")
        ax2.set_xlabel("False Positive Rate")
        ax2.set_ylabel("True Positive Rate")
        ax2.set_title("ROC Curve")
        ax2.legend(loc="lower right")
        st.pyplot(fig2)

    with tab_data:
        st.subheader("Dataset Overview")
        st.write("Target names:", target_names)
        st.write("Shape:", X.shape)
        st.dataframe(pd.concat([X, pd.Series(y, name="target")], axis=1).head(20))

if __name__ == "__main__":
    main()
