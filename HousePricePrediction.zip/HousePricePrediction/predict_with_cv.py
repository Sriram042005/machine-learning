import joblib
import cv2
import os
import pandas as pd

# Load model
model = joblib.load('house_price_model.pkl')

print("🏠 Enter House Details:\n")
bedrooms = int(input("Number of bedrooms (BHK): "))
area = int(input("Living area (sq ft): "))
bathrooms = int(input("Full bathrooms: "))
rooms = int(input("Total rooms: "))
garage = int(input("Garage area (sq ft): "))

# ✅ Fix feature name warning by using DataFrame
features = pd.DataFrame([{
    'BedroomAbvGr': bedrooms,
    'GrLivArea': area,
    'FullBath': bathrooms,
    'TotRmsAbvGrd': rooms,
    'GarageArea': garage
}])

# Predict price
price = model.predict(features)[0]
formatted_price = f"₹ {int(price):,}"

# ✅ Use correct paths and consistent extensions
image_map = {
    1: "images/1bhk.jpg",   # assuming no 1bhk.jpg
    2: "images/2bhk.webp",
    3: "images/3bhk.webp",
    4: "images/4bhk.jpg"
}
image_path = image_map.get(bedrooms, "images/3bhk.jpg")  # fallback

# Check if image exists
if not os.path.exists(image_path):
    print(f"❌ Image not found: {image_path}")
    exit()

# Load image
img = cv2.imread(image_path)

# Overlay price
font = cv2.FONT_HERSHEY_SIMPLEX
cv2.putText(img, "Predicted Price:", (50, 80), font, 1.2, (255, 255, 255), 2)
cv2.putText(img, formatted_price, (50, 140), font, 1.8, (0, 255, 0), 3)

# Show image
cv2.imshow("🏠 House Price Prediction", img)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Save image
cv2.imwrite("output_price_overlay.jpg", img)
print("✅ Output image saved as output_price_overlay.jpg")
