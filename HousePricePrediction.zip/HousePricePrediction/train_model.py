import pandas as pd
import joblib

# Load model
model = joblib.load('house_price_model.pkl')

# Get user input
bedrooms = int(input("Number of bedrooms (BHK): "))
area = int(input("Living area (sq ft): "))
bathrooms = int(input("Full bathrooms: "))
rooms = int(input("Total rooms: "))
garage = int(input("Garage area (sq ft): "))

# ✅ Build DataFrame with correct column names
features = pd.DataFrame([{
    'BedroomAbvGr': bedrooms,
    'GrLivArea': area,
    'FullBath': bathrooms,
    'TotRmsAbvGrd': rooms,
    'GarageArea': garage
}])

# ✅ Make prediction
price = model.predict(features)[0]
formatted_price = f"₹ {int(price):,}"

