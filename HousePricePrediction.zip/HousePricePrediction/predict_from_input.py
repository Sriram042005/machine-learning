import joblib

# Load model
model = joblib.load('house_price_model.pkl')

print("🏠 House Price Predictor\n")

# Get user input
bedrooms = int(input("Enter number of bedrooms (BHK): "))
area = int(input("Enter total living area in sq ft: "))
bathrooms = int(input("Enter number of full bathrooms: "))
rooms = int(input("Enter total number of rooms above ground: "))
garage = int(input("Enter garage area (sq ft): "))

# Predict
features = [[bedrooms, area, bathrooms, rooms, garage]]
price = model.predict(features)[0]

print(f"\n💰 Estimated House Price: ₹ {int(price):,}")
