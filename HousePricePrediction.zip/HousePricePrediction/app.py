import streamlit as st
import pandas as pd
import joblib
import cv2
import os
from PIL import Image
import numpy as np

# Load model
model = joblib.load("house_price_model.pkl")

# App title
st.title("🏠 House Price Predictor (BHK-Based)")

# User Inputs
st.sidebar.header("Enter House Details:")
bedrooms = st.sidebar.slider("Bedrooms (BHK)", 1, 6, 3)
area = st.sidebar.number_input("Living Area (sq ft)", value=1500)
bathrooms = st.sidebar.slider("Full Bathrooms", 1, 5, 2)
rooms = st.sidebar.slider("Total Rooms Above Ground", 1, 10, 6)
garage = st.sidebar.number_input("Garage Area (sq ft)", value=300)

if st.sidebar.button("Predict Price"):
    # Prepare input
    features = pd.DataFrame([{
        'BedroomAbvGr': bedrooms,
        'GrLivArea': area,
        'FullBath': bathrooms,
        'TotRmsAbvGrd': rooms,
        'GarageArea': garage
    }])
    
    price = model.predict(features)[0]
    formatted_price = f"₹ {int(price):,}"
    
    st.success(f"💰 Predicted House Price: {formatted_price}")

    # Image overlay
    image_map = {
        1: "images/2bhk.jpg",
        2: "images/2bhk.jpg",
        3: "images/3bhk.jpg",
        4: "images/4bhk.jpg"
    }
    img_path = image_map.get(bedrooms, "images/3bhk.jpg")

    if os.path.exists(img_path):
        # Load with cv2, draw text, convert to RGB
        img = cv2.imread(img_path)
        cv2.putText(img, formatted_price, (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.8, (0, 255, 0), 3)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # Convert to PIL and display
        pil_img = Image.fromarray(img)
        st.image(pil_img, caption="Predicted Price Overlaid on House", use_column_width=True)
    else:
        st.warning(f"Image not found: {img_path}")
