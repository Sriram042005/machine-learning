# app.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

try:
    import streamlit as st
    STREAMLIT_AVAILABLE = True
except ImportError:
    STREAMLIT_AVAILABLE = False


# -------------------- Predefined Training Data --------------------
def load_training_data():
    data = [
        [85, 45, 48, 90, "Good"],
        [70, 35, 30, 60, "Bad"],
        [90, 48, 46, 95, "Good"],
        [60, 28, 25, 55, "Bad"],
        [95, 50, 50, 98, "Good"],
        [75, 40, 42, 70, "Good"],
        [50, 20, 18, 40, "Bad"],
        [80, 44, 45, 85, "Good"],
        [65, 30, 32, 65, "Bad"],
    ]
    df = pd.DataFrame(data, columns=['Attendance', 'CAT1', 'CAT2', 'Discipline', 'Performance'])
    return df


# -------------------- Train Model --------------------
def train_model(df):
    X = df[['Attendance', 'CAT1', 'CAT2', 'Discipline']]
    y = df['Performance']

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = LogisticRegression()
    model.fit(X_scaled, y)

    return model, scaler


# -------------------- Predict --------------------
def predict_performance(model, scaler, features):
    features_scaled = scaler.transform([features])
    return model.predict(features_scaled)[0]


# -------------------- Bar Chart --------------------
def plot_bar_chart(features, username, average):
    labels = ['Attendance (%)', 'CAT 1', 'CAT 2', 'Discipline']
    plt.figure(figsize=(6, 4))
    bars = plt.bar(labels, features, color='mediumseagreen')
    plt.ylim(0, 100)
    plt.title(f"📊 {username}'s Performance Metrics")
    plt.ylabel("Value")

    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2.0, height + 1, f'{height:.1f}', ha='center', va='bottom', fontsize=9)

    plt.text(1.5, 95, f"Average: {average:.2f}", ha='center', fontsize=10, color='blue')

    plt.tight_layout()
    plt.savefig("bar_chart.png")
    plt.close()


# -------------------- Streamlit App --------------------
def run_streamlit():
    st.title("🎓 Predict Student Performance")

    username = st.text_input("Enter your name:")
    if not username:
        st.warning("Please enter your name to continue.")
        return

    st.markdown("### 📥 Enter Your Academic Data")

    attendance = st.slider("Attendance (%)", 0, 100, 75)
    cat1 = st.slider("CAT 1 Marks", 0, 50, 35)
    cat2 = st.slider("CAT 2 Marks", 0, 50, 38)
    discipline = st.slider("Discipline Rating (0–100)", 0, 100, 80)

    if st.button("Predict Performance"):
        df = load_training_data()
        model, scaler = train_model(df)
        features = [attendance, cat1, cat2, discipline]
        average = np.mean(features)
        prediction = predict_performance(model, scaler, features)

        st.success(f"🎯 Hello {username}, your predicted performance is: **{prediction}**")
        st.info(f"📊 Your average metric score: **{average:.2f}**")

        plot_bar_chart(features, username, average)
        st.image("bar_chart.png")


# -------------------- CLI Version --------------------
def run_terminal():
    print("\n🎓 Predict Student Performance (CLI Version)")
    username = input("Enter your name: ")

    a = float(input("Attendance (%): "))
    c1 = float(input("CAT 1 marks: "))
    c2 = float(input("CAT 2 marks: "))
    d = float(input("Discipline (0–100): "))

    df = load_training_data()
    model, scaler = train_model(df)

    features = [a, c1, c2, d]
    average = np.mean(features)
    prediction = predict_performance(model, scaler, features)

    print(f"\n🎯 {username}, your predicted performance is: {prediction}")
    print(f"📊 Your average score is: {average:.2f}")

    plot_bar_chart(features, username, average)
    print("📊 Bar chart saved as bar_chart.png")


# -------------------- Main --------------------
if __name__ == "__main__":
    if STREAMLIT_AVAILABLE:
        run_streamlit()
    else:

        run_terminal()


