import speech_recognition as sr
import pyttsx3
import pywhatkit
import wikipedia
from datetime import datetime, date


r = sr.Recognizer()
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty("voice", voices[1].id)


phone_numbers = {
    "udhaya": "9843567876",
    "kumar": "9843567656",
    "vignesh": "9876598544",
    "dinesh": "6574387564",
    "manohar": "8754367584"
}

def speak(text):
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()

def get_commands():
    try:
        with sr.Microphone() as source:
            r.adjust_for_ambient_noise(source)
            print("Listening... Ask now...")
            audio = r.listen(source)
            my_text = r.recognize_google(audio)
            my_text = my_text.lower()
            print("You said:", my_text)
            speak("You said: " + my_text)

            # Play on YouTube
            if 'play' in my_text:
                song = my_text.replace('play', '').strip()
                speak('Playing ' + song)
                pywhatkit.playonyt(song)

            # Date
            elif 'date' in my_text:
                today = date.today().strftime("%B %d, %Y")
                speak("Today's date is " + today)

            # Time
            elif 'time' in my_text:
                current_time = datetime.now().strftime("%I:%M %p")
                speak("The current time is " + current_time)

            # Phone Number
            elif "phone number" in my_text:
                found = False
                for name in phone_numbers:
                    if name in my_text:
                        found = True
                        speak(f"{name.title()}'s phone number is {phone_numbers[name]}")
                        break
                if not found:
                    speak("Sorry, I couldn't find the contact.")

            # Wikipedia
            elif "who is" in my_text:
                person = my_text.replace("who is", "").strip()
                try:
                    info = wikipedia.summary(person, 1)
                    speak(info)
                except:
                    speak("Sorry, I couldn't find information on that person.")

            else:
                speak("Sorry, I didn't understand that.")

    except Exception as e:
        print("ERROR:", e)
        speak("Sorry, something went wrong.")

# Run the assistant
get_commands()

  



